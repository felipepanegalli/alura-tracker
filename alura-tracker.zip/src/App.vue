<template>
  <main class="columns is-gapless is-multiline">
    <div class="column is-one-quarter">
      <TheSidebar />
    </div>
    <div class="column is-three-quarter">
      <TheForm />
    </div>
  </main>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import TheForm from "./components/TheForm.vue";
import TheSidebar from "./components/TheSidebar.vue";

export default defineComponent({
  name: "App",
  components: { TheSidebar, TheForm },
});
</script>

<style>
</style>
